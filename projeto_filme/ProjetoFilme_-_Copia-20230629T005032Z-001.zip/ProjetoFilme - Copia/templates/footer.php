
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.min.js" integrity="sha512-1/RvZTcCDEUjY/CypiMz+iqqtaoQfAITmNSJY17Myp4Ms5mdxPS5UV7iOfdZoxcGhzFbOm6sntTKJppjvuhg4g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<footer id="footer">
<div id="social-container">
    <ul>
        <li>
            <a href="#"><i class="fab fa-facebook-square"></i></a>
</li>
<li>
    <a href="#"><i class="fab fa-instagram"></i></a>
</li>
<li>
            <a href="#"><i class="fab fa-youtube"></i></a>
</li>
    </ul>
</div>
<div id="footer-links-container">
<ul>
        <li>
            <a href="#">Adicionar filme</a>
</li>
<li>
            <a href="#">Adicionar critica</a>
</li>
<li>
            <a href="<?= $BASE_URL ?>/auth.php">Entrar / Registrar</a>
</li>
</ul>
</div>
<p>&copy; Senac 2023</p>
</footer>

</body>
</html>

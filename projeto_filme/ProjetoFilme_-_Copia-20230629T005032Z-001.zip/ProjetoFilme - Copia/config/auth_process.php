<?php
include_once("url.php");
include_once("conexao.php");
include_once("../models/User.php");
require_once("../models/Message.php");
include_once("../dao/UserDAO.php");

$message = new Message($BASE_URL);
$userDAO = new UserDAO($conn, $BASE_URL);

// Resgata o tipo do formulario
$type = filter_input(INPUT_POST, "type");

//Verificação do tipo de formulário
if ($type === "register") {

    $nome = filter_input(INPUT_POST, "name");
    $ultimoNome = filter_input(INPUT_POST, "lastname");
    $email = filter_input(INPUT_POST, "email");
    $password = filter_input(INPUT_POST, "password");
    $confirmpassword = filter_input(INPUT_POST, "confirmpassword");

    //Verificação de dados mínimos
    if ($nome && $ultimoNome && $email && $password) {

        //verificar senhas
        if ($password != $confirmpassword) {
            $message->setMessage("As senhas não são iguais", "error", "back");
        }

        //Verificar se o email já está cadastrado no sistema
        else if ($userDAO->findByEmail($email) === false) {
            echo "E-mail não cadastrado";
            $user = new User();
            //cria token e senha
            $userToken = $user->generateToken();
            $finalPassword = $user->generatePassword($password);
            $user->name = $nome;
            $user->lastname = $ultimoNome;
            $user->email = $email;
            $user->password = $finalPassword;
            $user->token = $userToken;
            $auth = true;
            $userDAO->create($user, $auth);

        } //fim else if
        else {
            $message->setMessage("E-mail já cadastrado. Caso não lembre, recupere sua senha", "error", "back");
        }
    } //fim verifica dados minimos 
    else {
        $message->setMessage("Por favor, preencha todos os campos", "error", "back");
    }
} //Fim Register

?>
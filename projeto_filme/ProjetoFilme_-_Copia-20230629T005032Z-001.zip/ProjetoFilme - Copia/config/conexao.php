<?php
$host= "localhost";
$dbname = "dbfilmes";
$user = "root";
$pass = "senac";
$port = "3306";

try{
    $conn = new PDO("mysql:host=$host; port=$port; dbname=$dbname", $user, $pass);

    //ativa o modo de erros para retornar mensagem caso a conexão não seja bem sucedida
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){

    $erro = $e->getMessage();
    echo $erro;
}
?>